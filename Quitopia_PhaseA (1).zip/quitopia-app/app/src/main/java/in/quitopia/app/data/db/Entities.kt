package in.quitopia.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Aggregate of blocked requests, never a per-site history.
 *
 * Storing domains here would turn this table into a browsable record of the user's
 * worst moments — a privacy problem and a support nightmare. Counts by hour are all
 * the analytics the product needs.
 */
@Entity(tableName = "block_event", indices = [Index("hourBucket")])
data class BlockEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hourBucket: Long,
    val category: String,
    val layer: String,
    val count: Int
)

@Entity(tableName = "urge_log")
data class UrgeLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val trigger: String,
    val outcome: String,
    val note: String? = null
)

@Entity(tableName = "journal_entry")
data class JournalEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val cipherText: ByteArray,
    val iv: ByteArray
)

@Entity(tableName = "streak")
data class StreakEntity(
    @PrimaryKey val id: Int = 1,
    val currentStart: Long,
    val bestDays: Int,
    val lastBypassAt: Long?,
    val totalCleanDays: Int
)

/**
 * A rule the user typed in themselves. ALLOW always beats BLOCK, same as the
 * shipped allowlist, because a user who allowlists their bank must never be blocked.
 */
@Entity(tableName = "custom_rule", indices = [Index("pattern")])
data class CustomRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pattern: String,
    val isAllow: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)

/** Output of the six-question recovery questionnaire. One row, id = 1. */
@Entity(tableName = "recovery_plan")
data class RecoveryPlanEntity(
    @PrimaryKey val id: Int = 1,
    val createdAt: Long,
    val primaryCategory: String,
    val worstTimeOfDay: String,
    val biggestTrigger: String,
    val triedBefore: String,
    val toldSomeone: Boolean,
    val dailyAction: String
)

@Entity(tableName = "schedule")
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Bit 0 = Monday ... bit 6 = Sunday. */
    val daysMask: Int,
    val startMinute: Int,
    val endMinute: Int,
    val tier: String,
    val enabled: Boolean = true
)
