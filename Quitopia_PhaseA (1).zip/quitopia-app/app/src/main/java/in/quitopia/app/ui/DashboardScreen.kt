package in.quitopia.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import in.quitopia.app.blocklist.Category
import in.quitopia.app.domain.PanicEngine

/**
 * The integrity screen plus the panic switch.
 *
 * Order matters: the thing a user reaches for at 11 p.m. is at the top, the diagnostics
 * are below it. This is the screen that makes the product feel trustworthy, and it must
 * never lie — if a layer is down, it says so in red.
 */
@Composable
fun DashboardScreen(
    viewModel: AppViewModel,
    onOpenRecovery: () -> Unit,
    onOpenPlan: () -> Unit,
    onOpenLists: () -> Unit,
    onOpenContent: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(Unit) { viewModel.refresh() }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text("Quitopia", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(
                text = if (state.vpnRunning) "Protection is on" else "Protection is off",
                style = MaterialTheme.typography.titleSmall,
                color = if (state.vpnRunning) MaterialTheme.colorScheme.primary else Color(0xFFB3261E)
            )
            Spacer(Modifier.height(18.dp))

            PanicCard(viewModel, state.panicActive, state.panicLabel)

            Spacer(Modifier.height(18.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("This week", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                        Metric("${state.blockedTotal}", "blocks")
                        Metric("${state.streakDays}", "day streak")
                        Metric("${state.urgesLogged}", "urges")
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text("Quitting", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                text = state.categories.sortedBy { it.ordinal }.joinToString(" · ") { it.label },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(18.dp))
            Text("Integrity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))

            CheckRow("VPN filter", state.vpnRunning, "Start", viewModel::startProtection)
            HorizontalDivider()
            CheckRow("Always-on VPN", state.vpnRunning, "Settings", viewModel::openVpnSettings)
            HorizontalDivider()
            CheckRow("Usage access", state.usageAccess, "Grant", viewModel::openUsageAccess)
            HorizontalDivider()
            CheckRow("Battery exemption", state.batteryExempt, "Fix", viewModel::requestBattery)
            HorizontalDivider()
            CheckRow("Private DNS", state.privateDnsOk, "Fix", viewModel::openPrivateDns)

            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onOpenPlan, modifier = Modifier.weight(1f)) { Text("Your plan") }
                OutlinedButton(onClick = onOpenLists, modifier = Modifier.weight(1f)) { Text("Lists") }
                OutlinedButton(onClick = onOpenContent, modifier = Modifier.weight(1f)) { Text("Read") }
            }

            Spacer(Modifier.height(12.dp))
            Button(onClick = onOpenRecovery, modifier = Modifier.fillMaxWidth()) {
                Text("I have an urge")
            }
            Spacer(Modifier.height(10.dp))

            if (state.vpnRunning) {
                OutlinedButton(
                    onClick = {
                        viewModel.requestDisable()
                        viewModel.stopProtection()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Turn protection off (starts cooldown)") }
            }
        }
    }
}

@Composable
private fun PanicCard(viewModel: AppViewModel, active: Boolean, label: String) {
    if (active) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    "Panic switch is on",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB3261E)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "All internet is paused. Back in $label.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = viewModel::stopPanic) { Text("End early") }
            }
        }
        return
    }
    Button(
        onClick = { viewModel.startPanic(PanicEngine.DEFAULT_MS) },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E)),
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Panic", fontWeight = FontWeight.Bold)
            Text("Cut the internet for 15 minutes", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun Metric(value: String, label: String) {
    Column {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun CheckRow(label: String, ok: Boolean, fixLabel: String, onFix: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(
                    color = if (ok) Color(0xFF2E7D32) else Color(0xFFB3261E),
                    shape = CircleShape
                )
        )
        Spacer(Modifier.padding(horizontal = 6.dp))
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        if (!ok) {
            OutlinedButton(onClick = onFix) { Text(fixLabel) }
        } else {
            Text("OK", style = MaterialTheme.typography.labelMedium, color = Color(0xFF2E7D32))
        }
    }
}
