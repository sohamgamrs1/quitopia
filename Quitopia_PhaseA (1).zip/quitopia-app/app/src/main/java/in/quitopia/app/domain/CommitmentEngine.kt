package in.quitopia.app.domain

import in.quitopia.app.data.prefs.CommitmentState

/**
 * Cooldown arithmetic. Pure functions so they can be unit-tested without Android.
 *
 * The cheat this defends against: a user who sets the system clock forward a day to
 * skip the cooldown. We take the *minimum* of wall-clock progress and elapsed-realtime
 * progress, so moving the clock forward does nothing and moving it back does nothing.
 * elapsedRealtime resets on reboot, which only ever makes the cooldown longer — the
 * safe direction.
 */
object CommitmentEngine {

    const val COOLDOWN_MS: Long = 24L * 60L * 60L * 1000L

    fun remainingMillis(state: CommitmentState, nowWall: Long, nowElapsed: Long): Long {
        if (!state.hasPendingRequest) return COOLDOWN_MS
        val wallProgress = nowWall - state.requestedWall
        val elapsedProgress =
            if (nowElapsed >= state.requestedElapsed) nowElapsed - state.requestedElapsed else 0L
        val progressed = minOf(wallProgress, elapsedProgress).coerceAtLeast(0L)
        return (COOLDOWN_MS - progressed).coerceAtLeast(0L)
    }

    fun canDisableNow(state: CommitmentState, nowWall: Long, nowElapsed: Long): Boolean {
        if (state.tier == in.quitopia.app.data.prefs.CommitmentTier.OFF) return true
        if (!state.hasPendingRequest) return false
        return remainingMillis(state, nowWall, nowElapsed) == 0L
    }

    fun formatRemaining(millis: Long): String {
        if (millis <= 0) return "ready"
        val totalMinutes = millis / 60_000L
        val hours = totalMinutes / 60
        val minutes = totalMinutes % 60
        return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
    }
}
