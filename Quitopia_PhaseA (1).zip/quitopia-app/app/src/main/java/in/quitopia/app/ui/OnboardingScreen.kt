package in.quitopia.app.ui

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import in.quitopia.app.blocklist.Category
import in.quitopia.app.data.prefs.CommitmentTier

/**
 * Five steps, in the order the permissions must be requested.
 *
 * Each disclosure is on its own screen with its own affirmative action — that is a Play
 * requirement for both the VpnService and usage access, not a design preference.
 */
@Composable
fun OnboardingScreen(viewModel: AppViewModel, onFinished: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    val state by viewModel.state.collectAsState()

    // The system VPN consent dialog is an Activity result, not a permission request.
    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) viewModel.startProtection()
        step = 3
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(
                text = "Step ${step + 1} of 5",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(Modifier.height(12.dp))

            when (step) {
                0 -> WelcomeStep(
                    onContinue = { tier ->
                        viewModel.setTier(tier)
                        step = 1
                    }
                )
                1 -> CategoryStep(
                    selected = state.categories,
                    onToggle = viewModel::toggleCategory,
                    onContinue = { step = 2 }
                )
                2 -> DisclosureStep(
                    title = "Why Quitopia needs VPN access",
                    body = "Quitopia uses Android's VPN feature to filter traffic on this device. " +
                        "Nothing is sent to a server — the filter runs entirely on your phone. " +
                        "Android requires this dialog for any app that filters traffic.",
                    actionLabel = "Turn on protection",
                    onAction = {
                        val consent = viewModel.vpnConsentIntent()
                        if (consent != null) {
                            vpnLauncher.launch(consent)
                        } else {
                            viewModel.startProtection()
                            step = 3
                        }
                    },
                    onSkip = { step = 3 }
                )
                3 -> DisclosureStep(
                    title = "Why Quitopia needs usage access",
                    body = "To block apps you choose, Quitopia needs to know which app is open. " +
                        "We only see app names and times — never screen contents, keystrokes, " +
                        "or messages.",
                    actionLabel = "Open settings",
                    onAction = {
                        viewModel.openUsageAccess()
                        step = 4
                    },
                    onSkip = { step = 4 }
                )
                else -> DisclosureStep(
                    title = "Why Quitopia asks for device admin",
                    body = "Device admin is used for one thing: adding a delay before this app " +
                        "can be uninstalled, so a 2 a.m. decision does not undo a month of " +
                        "progress. It cannot erase data, lock the screen, or read anything.",
                    actionLabel = "Finish setup",
                    onAction = {
                        viewModel.requestBattery()
                        onFinished()
                    },
                    onSkip = { onFinished() }
                )
            }
        }
    }
}

@Composable
private fun WelcomeStep(onContinue: (CommitmentTier) -> Unit) {
    Text("Quitopia", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text(
        "A blocker that stays on, and does not watch you.",
        style = MaterialTheme.typography.titleMedium
    )
    Spacer(Modifier.height(24.dp))
    Text(
        "Choose how much friction you want. You can change this later, but changing it " +
            "takes a day — that is the point.",
        style = MaterialTheme.typography.bodyMedium
    )
    Spacer(Modifier.height(20.dp))

    TierButton("Gentle", "Blocks sites. Turning it off is one tap.", CommitmentTier.GENTLE, onContinue)
    Spacer(Modifier.height(10.dp))
    TierButton("Committed", "Turning it off needs a 24-hour cooldown.", CommitmentTier.COMMITTED, onContinue)
    Spacer(Modifier.height(10.dp))
    TierButton("Hard", "Cooldown, device admin, and app blocking.", CommitmentTier.HARD, onContinue)
}

@Composable
private fun TierButton(
    title: String,
    subtitle: String,
    tier: CommitmentTier,
    onContinue: (CommitmentTier) -> Unit
) {
    OutlinedButton(
        onClick = { onContinue(tier) },
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun CategoryStep(
    selected: Set<Category>,
    onToggle: (Category) -> Unit,
    onContinue: () -> Unit
) {
    Text("What are you quitting?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text(
        "Pick one to start. Adding everything at once is the fastest way to fail — you can " +
            "add another in two weeks.",
        style = MaterialTheme.typography.bodyMedium
    )
    Spacer(Modifier.height(18.dp))

    Category.entries.forEach { category ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selected.contains(category),
                onClick = { onToggle(category) },
                enabled = category != Category.ADULT,
                label = {
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        Text(category.label, fontWeight = FontWeight.Medium)
                        Text(category.blurb, style = MaterialTheme.typography.bodySmall)
                    }
                }
            )
        }
    }

    Spacer(Modifier.height(10.dp))
    Text(
        "Adult content is always on and cannot be turned off here.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(20.dp))
    Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
}

@Composable
private fun DisclosureStep(
    title: String,
    body: String,
    actionLabel: String,
    onAction: () -> Unit,
    onSkip: () -> Unit
) {
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    Text(body, style = MaterialTheme.typography.bodyLarge)
    Spacer(Modifier.height(28.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onClick = onAction, modifier = Modifier.weight(1f)) { Text(actionLabel) }
        OutlinedButton(onClick = onSkip, modifier = Modifier.weight(1f)) { Text("Skip") }
    }
}
