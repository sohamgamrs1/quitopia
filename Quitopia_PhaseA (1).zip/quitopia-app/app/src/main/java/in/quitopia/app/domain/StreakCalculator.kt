package in.quitopia.app.domain

object StreakCalculator {

    private const val DAY_MS = 24L * 60L * 60L * 1000L

    fun currentDays(startedAt: Long, now: Long): Int {
        if (now <= startedAt) return 0
        return ((now - startedAt) / DAY_MS).toInt()
    }

    /**
     * A bypass resets the current streak but never the best one. Losing everything at
     * 2 a.m. is exactly what makes people uninstall; keep the record of what they built.
     */
    fun afterBypass(startedAt: Long, now: Long, bestDays: Int, totalCleanDays: Int): Triple<Long, Int, Int> {
        val run = currentDays(startedAt, now)
        return Triple(now, maxOf(bestDays, run), totalCleanDays + run)
    }
}
