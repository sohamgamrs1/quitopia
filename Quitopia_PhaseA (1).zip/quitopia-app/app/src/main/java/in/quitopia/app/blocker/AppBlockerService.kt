package in.quitopia.app.blocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import in.quitopia.app.R
import in.quitopia.app.data.prefs.CommitmentStore
import in.quitopia.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Watches the foreground app and raises the intercept screen for blocked packages.
 *
 * This is deliberately not an AccessibilityService: same effect for our purpose, no
 * Play policy declaration, no rejection risk. The cost is up to one second of latency
 * and the price of a foreground notification.
 */
@AndroidEntryPoint
class AppBlockerService : Service() {

    @Inject lateinit var commitmentStore: CommitmentStore

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var pollJob: Job? = null
    private var usageStats: UsageStatsManager? = null
    private var lastQuery = 0L

    @Volatile private var blocked: Set<String> = emptySet()
    @Volatile private var lastIntercepted: String? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        usageStats = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        lastQuery = System.currentTimeMillis()

        scope.launch {
            commitmentStore.blockedPackages.collect { blocked = it }
        }

        pollJob = scope.launch {
            while (isActive) {
                val foreground = foregroundPackage()
                if (foreground != null &&
                    foreground in blocked &&
                    foreground != packageName &&
                    foreground != lastIntercepted
                ) {
                    lastIntercepted = foreground
                    intercept(foreground)
                }
                if (foreground != null && foreground != lastIntercepted) lastIntercepted = null
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private fun foregroundPackage(): String? {
        val manager = usageStats ?: return null
        val now = System.currentTimeMillis()
        val events = manager.queryEvents(lastQuery, now) ?: return null
        var result: String? = null
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                result = event.packageName
            }
        }
        lastQuery = now
        return result
    }

    private fun intercept(pkg: String) {
        Log.i(TAG, "intercepting $pkg")
        val intent = Intent(this, InterceptActivity::class.java)
            .putExtra(InterceptActivity.EXTRA_PACKAGE, pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        runCatching { startActivity(intent) }
            .onFailure { Log.w(TAG, "could not raise intercept screen", it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        pollJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.blocker_channel),
                NotificationManager.IMPORTANCE_MIN
            ).apply { setShowBadge(false) }
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.blocker_notification_title))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    companion object {
        private const val TAG = "QuitopiaBlocker"
        private const val CHANNEL_ID = "blocker"
        private const val NOTIFICATION_ID = 1002
        private const val POLL_INTERVAL_MS = 1000L

        @Volatile var running: Boolean = false
            private set

        fun start(context: Context) {
            context.startForegroundService(Intent(context, AppBlockerService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AppBlockerService::class.java))
        }
    }
}
