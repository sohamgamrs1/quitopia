package in.quitopia.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import in.quitopia.app.blocklist.BlocklistRepository
import javax.inject.Inject

@HiltAndroidApp
class QuitopiaApp : Application() {

    @Inject lateinit var blocklistRepository: BlocklistRepository

    override fun onCreate() {
        super.onCreate()
        // Build the first matcher and keep it in sync with the user's categories and
        // custom rules. The VPN thread only ever reads the finished object.
        blocklistRepository.start()
    }
}
