package in.quitopia.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import in.quitopia.app.domain.RecoveryPlan

/* ============================ Your plan ============================ */

@Composable
fun PlanScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val plan by viewModel.plan.collectAsState()
    val state by viewModel.state.collectAsState()

    var worstTime by remember { mutableStateOf("NIGHT") }
    var trigger by remember { mutableStateOf("LATE_NIGHT") }
    var triedBefore by remember { mutableStateOf("FAILED") }
    var toldSomeone by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            HeaderRow("Your plan", onBack)

            val existing = plan
            if (existing != null && !editing) {
                val preview = viewModel.planPreview(
                    RecoveryPlan.Answers(
                        category = existing.primaryCategory,
                        worstTimeOfDay = existing.worstTimeOfDay,
                        biggestTrigger = existing.biggestTrigger,
                        triedBefore = existing.triedBefore,
                        toldSomeone = existing.toldSomeone
                    )
                )
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(preview.headline, style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.height(16.dp))
                        Text("Today", style = MaterialTheme.typography.labelLarge)
                        Text(preview.dailyAction, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(14.dp))
                        Text("At the moment of an urge", style = MaterialTheme.typography.labelLarge)
                        Text(preview.urgeAction, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(14.dp))
                        Text("Locked window", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "${formatWindow(preview.schedule.startMinute)} – " +
                                "${formatWindow(preview.schedule.endMinute)}, every day",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { editing = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Build it again")
                }
                return@Column
            }

            Text(
                "Four questions. The answers decide your locked window, your daily action, " +
                    "and what to do in the ninety seconds when it gets hard.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(20.dp))

            Question("When is it worst?") {
                listOf("MORNING" to "Morning", "WORK" to "Work hours", "EVENING" to "Evening", "NIGHT" to "Late night")
                    .forEach { (key, label) ->
                        FilterChip(
                            selected = worstTime == key,
                            onClick = { worstTime = key },
                            label = { Text(label) }
                        )
                        Spacer(Modifier.height(4.dp))
                    }
            }

            Question("What sets it off?") {
                listOf(
                    "STRESSED" to "Stress",
                    "BORED" to "Boredom",
                    "LONELY" to "Loneliness",
                    "LATE_NIGHT" to "Being awake late"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = trigger == key,
                        onClick = { trigger = key },
                        label = { Text(label) }
                    )
                    Spacer(Modifier.height(4.dp))
                }
            }

            Question("Have you tried before?") {
                listOf("FIRST" to "First time", "FAILED" to "Yes, and it did not hold")
                    .forEach { (key, label) ->
                        FilterChip(
                            selected = triedBefore == key,
                            onClick = { triedBefore = key },
                            label = { Text(label) }
                        )
                        Spacer(Modifier.height(4.dp))
                    }
            }

            Question("Has anyone else been told?") {
                FilterChip(
                    selected = toldSomeone,
                    onClick = { toldSomeone = true },
                    label = { Text("Yes, someone knows") }
                )
                Spacer(Modifier.height(4.dp))
                FilterChip(
                    selected = !toldSomeone,
                    onClick = { toldSomeone = false },
                    label = { Text("No, nobody") }
                )
            }

            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    viewModel.savePlan(
                        RecoveryPlan.Answers(
                            category = state.categories.firstOrNull()?.key ?: "adult",
                            worstTimeOfDay = worstTime,
                            biggestTrigger = trigger,
                            triedBefore = triedBefore,
                            toldSomeone = toldSomeone
                        )
                    )
                    editing = false
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Build my plan") }
        }
    }
}

private fun formatWindow(minute: Int): String {
    val h = (minute / 60) % 24
    val m = minute % 60
    return "%02d:%02d".format(h, m)
}

@Composable
private fun Question(title: String, content: @Composable () -> Unit) {
    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    content()
    Spacer(Modifier.height(18.dp))
}

/* ============================ Lists ============================ */

@Composable
fun ListEditorScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val rules by viewModel.rules.collectAsState()
    var input by remember { mutableStateOf("") }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            HeaderRow("Your lists", onBack)
            Text(
                "Add a site you want blocked, or one that must never be blocked. " +
                    "An allowed site always wins, even if a blocklist matches it.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("example.com") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        viewModel.addRule(input, isAllow = false)
                        input = ""
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Block it") }
                OutlinedButton(
                    onClick = {
                        viewModel.addRule(input, isAllow = true)
                        input = ""
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Allow it") }
            }

            Spacer(Modifier.height(18.dp))
            HorizontalDivider()
            Spacer(Modifier.height(10.dp))

            if (rules.isEmpty()) {
                Text(
                    "Nothing of your own yet. The shipped lists are doing the work.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    items(rules) { rule ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rule.pattern, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    if (rule.isAllow) "allowed" else "blocked",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            OutlinedButton(onClick = { viewModel.deleteRule(rule.id) }) {
                                Text("Remove")
                            }
                        }
                    }
                }
            }
        }
    }
}

/* ============================ Content ============================ */

@Composable
fun ContentScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val articles by viewModel.articles.collectAsState()
    var openId by remember { mutableStateOf<String?>(null) }

    Surface(modifier = Modifier.fillMaxSize()) {
        val open = articles.firstOrNull { it.id == openId }
        if (open != null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp)
            ) {
                HeaderRow(open.title, onBack = { openId = null })
                Text(
                    "${open.minutes} min read · works offline",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))
                open.body.split("\n\n").forEach { paragraph ->
                    Text(paragraph, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(12.dp))
                }
            }
            return@Surface
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            HeaderRow("Read", onBack)
            Text(
                "Six short pieces. No account, no video, no bandwidth.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(articles) { article ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                article.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                "${article.minutes} min",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(onClick = { openId = article.id }) { Text("Open") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun HeaderRow(title: String, onBack: () -> Unit) {
    Row {
        Text(
            title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onBack) { Text("Back") }
    }
    Spacer(Modifier.height(10.dp))
}
