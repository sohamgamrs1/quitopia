package in.quitopia.app.domain

import in.quitopia.app.data.db.RecoveryPlanEntity
import in.quitopia.app.data.db.ScheduleEntity

/**
 * Turns six answers into a plan with three concrete things to do.
 *
 * This is a rules engine, not a personality test. Every branch produces a schedule
 * window the user can see, an alternative action they can take at the moment of an
 * urge, and one line of copy that refers to what they actually told us.
 */
object RecoveryPlan {

    data class Answers(
        val category: String,
        val worstTimeOfDay: String,
        val biggestTrigger: String,
        val triedBefore: String,
        val toldSomeone: Boolean
    )

    data class Plan(
        val schedule: ScheduleEntity,
        val dailyAction: String,
        val headline: String,
        val urgeAction: String
    )

    fun build(answers: Answers): Plan {
        val window = when (answers.worstTimeOfDay) {
            "NIGHT" -> 22 * 60 to 6 * 60
            "EVENING" -> 20 * 60 to 24 * 60 - 1
            "MORNING" -> 6 * 60 to 10 * 60
            "WORK" -> 10 * 60 to 18 * 60
            else -> 22 * 60 to 6 * 60
        }

        val urgeAction = when (answers.biggestTrigger) {
            "STRESSED" -> "Two minutes of slow breathing, then a walk to another room."
            "BORED" -> "Stand up and do one small physical task — dishes, water, stairs."
            "LONELY" -> "Send one message to a real person. Any person. One line is enough."
            "LATE_NIGHT" -> "Put the phone outside the bedroom and lie down for ten minutes."
            else -> "Leave the room the phone is in, and breathe for sixty seconds."
        }

        val headline = when {
            !answers.toldSomeone -> "You have not told anyone yet. That is the single biggest thing you can change this week."
            answers.triedBefore == "FAILED" -> "You have tried before and it did not hold. This time the app is doing the work, not your willpower."
            else -> "You have done this before. The plan is there to make it easier, not harder."
        }

        val dailyAction = when (answers.worstTimeOfDay) {
            "NIGHT", "LATE_NIGHT" -> "Charge the phone outside the bedroom tonight."
            "MORNING" -> "Do the first twenty minutes of the day without picking up the phone."
            else -> "Log one urge today, even if you resist it easily."
        }

        return Plan(
            schedule = ScheduleEntity(
                daysMask = 0b1111111,
                startMinute = window.first,
                endMinute = window.second,
                tier = "HARD"
            ),
            dailyAction = dailyAction,
            headline = headline,
            urgeAction = urgeAction
        )
    }

    fun toEntity(answers: Answers, plan: Plan): RecoveryPlanEntity = RecoveryPlanEntity(
        createdAt = System.currentTimeMillis(),
        primaryCategory = answers.category,
        worstTimeOfDay = answers.worstTimeOfDay,
        biggestTrigger = answers.biggestTrigger,
        triedBefore = answers.triedBefore,
        toldSomeone = answers.toldSomeone,
        dailyAction = plan.dailyAction
    )
}
