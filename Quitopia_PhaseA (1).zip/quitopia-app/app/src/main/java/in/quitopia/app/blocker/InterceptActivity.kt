package in.quitopia.app.blocker

import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import in.quitopia.app.ui.theme.QuitopiaTheme
import kotlinx.coroutines.delay

/**
 * Full-screen intercept. Opaque, not a dialog, so the blocked app's content never
 * renders behind it.
 *
 * The ten-second pause before "Close" is the whole point: it is long enough to break
 * an impulse and short enough that nobody feels trapped.
 */
class InterceptActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuitopiaTheme {
                var secondsLeft by remember { mutableLongStateOf(PAUSE_SECONDS) }
                LaunchedEffect(Unit) {
                    val started = SystemClock.elapsedRealtime()
                    while (secondsLeft > 0) {
                        delay(250)
                        secondsLeft = PAUSE_SECONDS - (SystemClock.elapsedRealtime() - started) / 1000
                    }
                }
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "This app is blocked",
                            style = MaterialTheme.typography.headlineMedium,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "You chose to block it. Nothing is wrong with your phone.",
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 12.dp, bottom = 32.dp)
                        )
                        Text(
                            text = "Take one slow breath. You can close this in ${secondsLeft.coerceAtLeast(0)}s.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = {
                                startActivity(
                                    android.content.Intent(android.content.Intent.ACTION_MAIN)
                                        .addCategory(android.content.Intent.CATEGORY_HOME)
                                )
                                finish()
                            },
                            enabled = secondsLeft <= 0,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 32.dp)
                        ) {
                            Text(if (secondsLeft <= 0) "Close" else "Wait ${secondsLeft}s")
                        }
                        OutlinedButton(
                            onClick = { finish() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Text("Log an urge instead")
                        }
                    }
                }
            }
        }
    }

    companion object {
        const val EXTRA_PACKAGE = "extra_package"
        private const val PAUSE_SECONDS = 10L
    }
}
