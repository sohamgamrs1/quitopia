package in.quitopia.app.boot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import in.quitopia.app.blocker.AppBlockerService
import in.quitopia.app.util.Permissions
import in.quitopia.app.vpn.QuitopiaVpnService

/**
 * Restarts protection after a reboot.
 *
 * Note: the reliable way to survive a reboot is always-on VPN, configured in system
 * settings during onboarding. This receiver is the belt to that braces — it works when
 * the user has already granted VPN consent, and stays quiet when they have not.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        Log.i(TAG, "restoring protection after $action")
        runCatching { AppBlockerService.start(context) }
            .onFailure { Log.w(TAG, "blocker restart failed", it) }

        if (Permissions.hasVpnConsent(context)) {
            runCatching { QuitopiaVpnService.start(context) }
                .onFailure { Log.w(TAG, "vpn restart failed", it) }
        }
    }

    companion object {
        private const val TAG = "QuitopiaBoot"
    }
}
