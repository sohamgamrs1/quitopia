package in.quitopia.app.domain

import in.quitopia.app.data.prefs.PanicState

/**
 * The panic switch: cut the network now, get it back in a fixed window.
 *
 * Deliberately time-boxed. A permanent cut is a trap — the user uninstalls, and then
 * you have lost the whole install over one bad night.
 */
object PanicEngine {

    const val SHORT_MS: Long = 5 * 60 * 1000L
    const val DEFAULT_MS: Long = 15 * 60 * 1000L
    const val LONG_MS: Long = 60 * 60 * 1000L

    fun isActive(state: PanicState, nowElapsed: Long): Boolean =
        remainingMillis(state, nowElapsed) > 0

    fun remainingMillis(state: PanicState, nowElapsed: Long): Long {
        if (state.durationMs <= 0L || state.startedElapsed <= 0L) return 0L
        if (nowElapsed < state.startedElapsed) return 0L // rebooted since it started
        return (state.durationMs - (nowElapsed - state.startedElapsed)).coerceAtLeast(0L)
    }

    fun formatRemaining(millis: Long): String {
        if (millis <= 0L) return "off"
        val totalSeconds = millis / 1000L
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"
    }
}
