package in.quitopia.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Log
import dagger.hilt.android.AndroidEntryPoint
import in.quitopia.app.R
import in.quitopia.app.blocklist.BlocklistRepository
import in.quitopia.app.data.db.BlockEventDao
import in.quitopia.app.data.db.BlockEventEntity
import in.quitopia.app.data.prefs.CommitmentStore
import in.quitopia.app.domain.PanicEngine
import in.quitopia.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject

/**
 * The filtering VPN. Two modes, one service.
 *
 * DNS_ONLY (default) — the tunnel routes only the fake DNS address, so nothing but
 * name lookups enters it. Cheap, battery-friendly, and the reason there is no
 * user-space TCP stack in this codebase yet.
 *
 * PANIC — the tunnel routes 0.0.0.0/0 and every packet is dropped. The phone is
 * offline to everything except emergency calling, for a fixed window. This is what
 * the panic switch does, and it needs no new permissions and no root.
 */
@AndroidEntryPoint
class QuitopiaVpnService : VpnService() {

    @Inject lateinit var blocklistRepository: BlocklistRepository
    @Inject lateinit var commitmentStore: CommitmentStore
    @Inject lateinit var blockEventDao: BlockEventDao

    private enum class Mode { DNS_ONLY, PANIC }

    private val lock = Any()
    private var tunnel: ParcelFileDescriptor? = null
    private var worker: Thread? = null

    @Volatile private var stopReader = false
    @Volatile private var mode = Mode.DNS_ONLY
    @Volatile private var panicRemainingMs = 0L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var flushJob: Job? = null
    private var modeJob: Job? = null

    private val pendingBlocks = AtomicInteger(0)
    private val pendingSafeSearches = AtomicInteger(0)

    override fun onCreate() {
        super.onCreate()
        running.set(true)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                return START_NOT_STICKY
            }
        }
        if (tunnel == null) startTunnel()
        if (tunnel == null) return START_NOT_STICKY
        goForeground()
        startModeWatcher()
        startFlushLoop()
        return START_STICKY
    }

    /**
     * Called after establish(): the systemExempted foreground type is only allowed once
     * the app is an active VPN, so raising the notification first can throw on API 34+.
     */
    private fun goForeground() {
        try {
            startForeground(NOTIFICATION_ID, buildNotification())
        } catch (e: Exception) {
            Log.w(TAG, "typed foreground start refused, falling back", e)
            runCatching { startForeground(NOTIFICATION_ID, buildNotification()) }
        }
    }

    // ---- tunnel lifecycle ----------------------------------------------------

    private fun startTunnel() = synchronized(lock) {
        if (tunnel != null) return@synchronized

        val builder = Builder()
            .setSession(SESSION)
            .addAddress(TUN_ADDRESS, 32)
            .addDnsServer(FAKE_DNS)
            .setMtu(1500)
            .setBlocking(true)

        if (mode == Mode.PANIC) {
            builder.addRoute("0.0.0.0", 0)
        } else {
            builder.addRoute(FAKE_DNS, 32)
        }

        try {
            builder.addDisallowedApplication(packageName)
        } catch (e: Exception) {
            Log.w(TAG, "could not exclude own package", e)
        }

        val descriptor = try {
            builder.establish()
        } catch (e: Exception) {
            Log.e(TAG, "establish failed", e)
            null
        }
        if (descriptor == null) {
            Log.w(TAG, "VPN consent missing or revoked")
            stopSelf()
            return@synchronized
        }

        tunnel = descriptor
        stopReader = false
        worker = Thread({ pump(descriptor) }, "quitopia-tun").also { it.start() }
        Log.i(TAG, "tunnel established in $mode")
    }

    /** Rebuild the interface when the mode changes. Dropping the fd is the only way. */
    private fun rebuildTunnel(newMode: Mode) = synchronized(lock) {
        if (newMode == mode && tunnel != null) return@synchronized
        Log.i(TAG, "switching tunnel $mode -> $newMode")
        mode = newMode
        stopReader = true
        runCatching { tunnel?.close() }
        worker?.join(1500)
        tunnel = null
        worker = null
        stopReader = false
        startTunnel()
        notifyStatus()
    }

    private fun pump(descriptor: ParcelFileDescriptor) {
        val input = FileInputStream(descriptor.fileDescriptor)
        val output = FileOutputStream(descriptor.fileDescriptor)
        val buffer = ByteArray(32_767)

        val proxy = DnsProxy(
            matcherProvider = { blocklistRepository.current() },
            protect = { socket -> protect(socket) },
            safeSearchEnabled = true,
            onBlocked = { pendingBlocks.incrementAndGet() },
            onSafeSearch = { pendingSafeSearches.incrementAndGet() }
        )

        while (!stopReader) {
            val read = try {
                input.read(buffer)
            } catch (e: IOException) {
                if (!stopReader) Log.w(TAG, "tun read failed", e)
                break
            }
            if (read <= 0) continue
            if (mode == Mode.PANIC) continue // drop everything: that is the panic switch

            val reply = try {
                proxy.handle(buffer, read)
            } catch (e: Exception) {
                Log.w(TAG, "dns handling failed", e)
                null
            } ?: continue

            try {
                output.write(reply)
            } catch (e: IOException) {
                if (!stopReader) Log.w(TAG, "tun write failed", e)
                break
            }
        }
    }

    // ---- mode watcher --------------------------------------------------------

    private fun startModeWatcher() {
        if (modeJob?.isActive == true) return
        modeJob = scope.launch {
            while (isActive) {
                val state = runCatching { commitmentStore.panic.first() }.getOrNull()
                val remaining = if (state == null) 0L
                else PanicEngine.remainingMillis(state, SystemClock.elapsedRealtime())
                panicRemainingMs = remaining
                val desired = if (remaining > 0L) Mode.PANIC else Mode.DNS_ONLY
                if (desired != mode) rebuildTunnel(desired)
                delay(MODE_POLL_MS)
            }
        }
    }

    /** Writes one aggregate row a minute instead of one row per block. */
    private fun startFlushLoop() {
        if (flushJob?.isActive == true) return
        flushJob = scope.launch {
            while (isActive) {
                delay(FLUSH_INTERVAL_MS)
                val blocks = pendingBlocks.getAndSet(0)
                if (blocks > 0) record("BLOCKED", blocks)
                val safe = pendingSafeSearches.getAndSet(0)
                if (safe > 0) record("SAFE_SEARCH", safe)
            }
        }
    }

    private suspend fun record(layer: String, count: Int) {
        val hour = System.currentTimeMillis() / 3_600_000L * 3_600_000L
        runCatching {
            blockEventDao.insert(
                BlockEventEntity(hourBucket = hour, category = "adult", layer = layer, count = count)
            )
        }.onFailure { Log.w(TAG, "could not record $layer", it) }
    }

    // ---- teardown ------------------------------------------------------------

    private fun stopTunnel() {
        running.set(false)
        modeJob?.cancel()
        flushJob?.cancel()
        synchronized(lock) {
            stopReader = true
            runCatching { tunnel?.close() }
            worker?.join(1000)
            tunnel = null
            worker = null
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        Log.w(TAG, "vpn revoked by the system")
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        running.set(false)
        scope.cancel()
        runCatching { tunnel?.close() }
        tunnel = null
        super.onDestroy()
    }

    // ---- notification --------------------------------------------------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val panic = mode == Mode.PANIC
        val title = if (panic) "Panic switch is on" else getString(R.string.vpn_notification_title)
        val text = if (panic) {
            "All internet is paused. Back in ${PanicEngine.formatRemaining(panicRemainingMs)}."
        } else {
            getString(R.string.vpn_notification_text)
        }
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun notifyStatus() {
        runCatching {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, buildNotification())
        }
    }

    companion object {
        private const val TAG = "QuitopiaVpn"
        private const val CHANNEL_ID = "protection"
        private const val NOTIFICATION_ID = 1001
        private const val SESSION = "Quitopia"
        private const val TUN_ADDRESS = "10.111.222.1"
        private const val FAKE_DNS = "10.111.222.2"
        private const val FLUSH_INTERVAL_MS = 60_000L
        private const val MODE_POLL_MS = 2_000L

        const val ACTION_STOP = "in.quitopia.app.action.STOP_VPN"

        val running = AtomicBoolean(false)

        fun start(context: Context) {
            context.startForegroundService(Intent(context, QuitopiaVpnService::class.java))
        }

        fun stop(context: Context) {
            val intent = Intent(context, QuitopiaVpnService::class.java).setAction(ACTION_STOP)
            context.startService(intent)
        }
    }
}
