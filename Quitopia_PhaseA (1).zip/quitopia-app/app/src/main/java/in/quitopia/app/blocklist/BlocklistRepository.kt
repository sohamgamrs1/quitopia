package in.quitopia.app.blocklist

import android.content.Context
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import in.quitopia.app.data.db.CustomRuleDao
import in.quitopia.app.data.db.CustomRuleEntity
import in.quitopia.app.data.prefs.CommitmentStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the one matcher the VPN thread reads from.
 *
 * The packet path must never touch a database or block on IO, so it only ever does a
 * volatile read of [current]. Everything expensive — reading assets, merging the
 * user's own rules, building the trie — happens here, off the hot path, and the
 * finished matcher is swapped in atomically.
 */
@Singleton
class BlocklistRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val commitmentStore: CommitmentStore,
    private val customRuleDao: CustomRuleDao
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    @Volatile
    private var matcher: DomainMatcher = DomainMatcher.fromRules(emptyList(), emptyList())

    /** Cached per-category rule sets so switching a category does not re-read assets. */
    private val categoryCache = HashMap<Category, List<String>>()
    private var allowlistCache: List<String>? = null

    @Volatile
    var loaded: Boolean = false
        private set

    fun current(): DomainMatcher = matcher

    val customRules: Flow<List<CustomRuleEntity>> = customRuleDao.observeAll()

    /** Called once at startup and again whenever a category or custom rule changes. */
    fun start() {
        scope.launch {
            combine(commitmentStore.enabledCategories, customRuleDao.observeAll()) { cats, rules ->
                cats to rules
            }.collect { (cats, rules) ->
                rebuild(cats, rules)
            }
        }
    }

    suspend fun rebuild(enabled: Set<Category>, rules: List<CustomRuleEntity>) = mutex.withLock {
        val started = System.currentTimeMillis()
        val block = ArrayList<String>(4096)
        for (category in enabled) {
            block.addAll(categoryRules(category))
        }
        for (rule in rules) {
            if (rule.isAllow) continue
            block.add(rule.pattern)
        }
        val allow = ArrayList<String>(512)
        allow.addAll(allowlist())
        for (rule in rules) {
            if (rule.isAllow) allow.add(rule.pattern)
        }
        matcher = DomainMatcher.fromRules(block, allow)
        loaded = true
        Log.i(
            TAG,
            "matcher rebuilt: ${matcher.blockCount} block, ${matcher.allowCount} allow, " +
                "${System.currentTimeMillis() - started} ms, categories=$enabled"
        )
    }

    private fun categoryRules(category: Category): List<String> =
        categoryCache.getOrPut(category) { readAsset(category.asset) }

    private fun allowlist(): List<String> =
        allowlistCache ?: readAsset("allowlist.txt").also { allowlistCache = it }

    private fun readAsset(path: String): List<String> = try {
        context.assets.open(path).bufferedReader().useLines { lines ->
            lines.map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .toList()
        }
    } catch (e: Exception) {
        Log.e(TAG, "could not read $path", e)
        emptyList()
    }

    private companion object {
        const val TAG = "QuitopiaLists"
    }
}
