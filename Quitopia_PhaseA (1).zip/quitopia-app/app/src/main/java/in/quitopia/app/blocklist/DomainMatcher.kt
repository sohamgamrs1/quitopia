package in.quitopia.app.blocklist

import java.net.IDN

/**
 * Suffix matcher for domain blocklists.
 *
 * Rules are matched on reversed labels, so a rule for `example.com` also blocks
 * `a.b.example.com` without enumerating subdomains. Allowlist rules always win.
 *
 * The structure is immutable once built, which is what lets the VPN thread hold a
 * reference to it while a new list is composed on another thread and swapped in.
 */
class DomainMatcher private constructor(
    private val blockRoot: Node,
    private val allowRoot: Node,
    val blockCount: Int,
    val allowCount: Int
) {

    private class Node {
        val children = HashMap<Char, Node>(4)
        var terminal = false
    }

    fun isBlocked(host: String): Boolean {
        val name = normalize(host) ?: return false
        if (matches(allowRoot, name)) return false
        return matches(blockRoot, name)
    }

    private fun matches(root: Node, name: String): Boolean {
        var node = root
        var i = name.length - 1
        while (i >= 0) {
            val child = node.children[name[i]] ?: return false
            node = child
            if (node.terminal && (i == 0 || name[i - 1] == '.')) return true
            i--
        }
        return node.terminal
    }

    companion object {

        private const val MAX_HOST = 253

        /** Lowercases, punycodes and validates a hostname. Returns null if unusable. */
        fun normalize(raw: String): String? {
            var h = raw.trim().lowercase()
            if (h.isEmpty()) return null
            h = h.removePrefix("http://").removePrefix("https://")
            h = h.substringBefore('/')
            h = h.substringBefore(':')
            h = h.trimEnd('.')
            if (h.isEmpty() || h.length > MAX_HOST) return null
            val ascii = try {
                IDN.toASCII(h, IDN.ALLOW_UNASSIGNED)
            } catch (e: IllegalArgumentException) {
                return null
            }.lowercase()
            if (ascii.isEmpty() || ascii.length > MAX_HOST) return null
            if (!ascii.contains('.')) return null
            if (ascii.any { it == ' ' || it == '\u0000' }) return null
            return ascii
        }

        fun fromLines(lines: Sequence<String>): DomainMatcher {
            val block = ArrayList<String>()
            val allow = ArrayList<String>()
            for (rawLine in lines) {
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) continue
                if (line.startsWith("!")) allow.add(line.substring(1)) else block.add(line)
            }
            return fromRules(block, allow)
        }

        /** Compose one matcher out of every enabled category plus the user's own rules. */
        fun fromRules(blockRules: Collection<String>, allowRules: Collection<String>): DomainMatcher {
            val block = Node()
            val allow = Node()
            var b = 0
            var a = 0
            for (rule in allowRules) {
                val host = normalize(rule) ?: continue
                if (insert(allow, host)) a++
            }
            for (rule in blockRules) {
                val host = normalize(rule) ?: continue
                if (insert(block, host)) b++
            }
            return DomainMatcher(block, allow, b, a)
        }

        private fun insert(root: Node, name: String): Boolean {
            var node = root
            for (i in name.length - 1 downTo 0) {
                node = node.children.getOrPut(name[i]) { Node() }
            }
            val fresh = !node.terminal
            node.terminal = true
            return fresh
        }
    }
}
