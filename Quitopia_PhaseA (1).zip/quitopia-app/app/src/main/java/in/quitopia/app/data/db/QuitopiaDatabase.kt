package in.quitopia.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        BlockEventEntity::class,
        UrgeLogEntity::class,
        JournalEntryEntity::class,
        StreakEntity::class,
        ScheduleEntity::class,
        CustomRuleEntity::class,
        RecoveryPlanEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class QuitopiaDatabase : RoomDatabase() {
    abstract fun blockEventDao(): BlockEventDao
    abstract fun urgeLogDao(): UrgeLogDao
    abstract fun journalDao(): JournalDao
    abstract fun streakDao(): StreakDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun customRuleDao(): CustomRuleDao
    abstract fun recoveryPlanDao(): RecoveryPlanDao
}
