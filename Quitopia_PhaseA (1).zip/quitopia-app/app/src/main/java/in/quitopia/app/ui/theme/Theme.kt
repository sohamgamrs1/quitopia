package in.quitopia.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Navy = Color(0xFF1F3864)
private val Steel = Color(0xFF2E5C8A)
private val Mist = Color(0xFFEAF0F8)
private val Ink = Color(0xFF1A1A1A)
private val Paper = Color(0xFFFBFCFE)

private val Light = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    secondary = Steel,
    onSecondary = Color.White,
    primaryContainer = Mist,
    onPrimaryContainer = Navy,
    background = Paper,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink
)

private val Dark = darkColorScheme(
    primary = Color(0xFF9DB7E4),
    onPrimary = Color(0xFF10203A),
    secondary = Color(0xFF8FB2DA),
    onSecondary = Color(0xFF10203A),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE6E8EC),
    surface = Color(0xFF181D23),
    onSurface = Color(0xFFE6E8EC)
)

@Composable
fun QuitopiaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) Dark else Light,
        typography = Typography(),
        content = content
    )
}
