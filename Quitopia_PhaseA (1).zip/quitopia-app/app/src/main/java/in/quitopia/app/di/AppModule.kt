package in.quitopia.app.di

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import in.quitopia.app.data.db.BlockEventDao
import in.quitopia.app.data.db.JournalDao
import in.quitopia.app.data.db.QuitopiaDatabase
import in.quitopia.app.data.db.CustomRuleDao
import in.quitopia.app.data.db.RecoveryPlanDao
import in.quitopia.app.data.db.ScheduleDao
import in.quitopia.app.data.db.StreakDao
import in.quitopia.app.data.db.UrgeLogDao
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun database(@ApplicationContext context: Context): QuitopiaDatabase =
        Room.databaseBuilder(context, QuitopiaDatabase::class.java, "quitopia.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun blockEventDao(db: QuitopiaDatabase): BlockEventDao = db.blockEventDao()
    @Provides fun urgeLogDao(db: QuitopiaDatabase): UrgeLogDao = db.urgeLogDao()
    @Provides fun journalDao(db: QuitopiaDatabase): JournalDao = db.journalDao()
    @Provides fun streakDao(db: QuitopiaDatabase): StreakDao = db.streakDao()
    @Provides fun scheduleDao(db: QuitopiaDatabase): ScheduleDao = db.scheduleDao()
    @Provides fun customRuleDao(db: QuitopiaDatabase): CustomRuleDao = db.customRuleDao()
    @Provides fun recoveryPlanDao(db: QuitopiaDatabase): RecoveryPlanDao = db.recoveryPlanDao()

}
