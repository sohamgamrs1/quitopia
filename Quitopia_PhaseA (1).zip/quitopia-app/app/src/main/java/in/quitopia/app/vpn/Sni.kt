package in.quitopia.app.vpn

/**
 * Extracts the hostname from a TLS ClientHello.
 *
 * Not wired into the shipping tunnel yet — the narrow-route DNS tunnel never sees a
 * TCP stream. This is the tested building block for the full-route mode in Phase A:
 * once packets are forwarded through a userspace stack, the first payload of each
 * TCP/443 flow is passed here and the decision is made before the connection is
 * allowed to continue.
 *
 * Handles the realistic cases: split ClientHello (caller buffers), resumed sessions
 * (same layout), and non-TLS payloads (returns null).
 */
object Sni {

    private const val RECORD_HANDSHAKE = 0x16
    private const val HANDSHAKE_CLIENT_HELLO = 0x01
    private const val EXT_SERVER_NAME = 0x0000

    fun extract(payload: ByteArray, length: Int = payload.size): String? {
        if (length < 43) return null
        if ((payload[0].toInt() and 0xFF) != RECORD_HANDSHAKE) return null
        if ((payload[5].toInt() and 0xFF) != HANDSHAKE_CLIENT_HELLO) return null

        var p = 43 // 5 byte record header + 4 byte handshake header + 2 version + 32 random
        if (p >= length) return null

        val sessionIdLength = payload[p].toInt() and 0xFF
        p += 1 + sessionIdLength
        if (p + 2 > length) return null

        val cipherSuitesLength = u16(payload, p)
        p += 2 + cipherSuitesLength
        if (p + 1 > length) return null

        val compressionLength = payload[p].toInt() and 0xFF
        p += 1 + compressionLength
        if (p + 2 > length) return null

        val extensionsLength = u16(payload, p)
        p += 2
        val end = minOf(p + extensionsLength, length)

        while (p + 4 <= end) {
            val type = u16(payload, p)
            val size = u16(payload, p + 2)
            p += 4
            if (type == EXT_SERVER_NAME) {
                if (p + 5 > end) return null
                // list length (2) + type (1) + name length (2)
                val nameLength = u16(payload, p + 3)
                if (p + 5 + nameLength > end) return null
                return String(payload, p + 5, nameLength, Charsets.US_ASCII)
            }
            p += size
        }
        return null
    }

    private fun u16(buf: ByteArray, at: Int): Int =
        ((buf[at].toInt() and 0xFF) shl 8) or (buf[at + 1].toInt() and 0xFF)
}
