package in.quitopia.app.vpn

import in.quitopia.app.blocklist.DomainMatcher
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Answers DNS queries that arrive on the tun interface.
 *
 * Order of decisions, per query:
 *   1. Safe search — covered hosts get a CNAME to the forced-safe variant.
 *   2. Blocklist   — matched hosts get NXDOMAIN, built locally, zero network cost.
 *   3. Everything else is forwarded upstream through a protected socket.
 *
 * Replies are wrapped back into a minimal IPv4/UDP packet. The UDP checksum is left
 * at zero, which is legal for IPv4 (RFC 768) and saves a pseudo-header pass.
 *
 * The matcher is read through a provider rather than held as a field: the repository
 * swaps in a rebuilt matcher whenever the user changes a category or adds a rule, and
 * the packet thread must pick that up without restarting the tunnel.
 */
class DnsProxy(
    private val matcherProvider: () -> DomainMatcher,
    private val protect: (DatagramSocket) -> Boolean,
    private val safeSearchEnabled: Boolean = true,
    private val onBlocked: (String) -> Unit = {},
    private val onSafeSearch: (String) -> Unit = {}
) {

    private val upstream: InetAddress = InetAddress.getByName(UPSTREAM)

    fun handle(packet: ByteArray, length: Int): ByteArray? {
        if (length < 28) return null
        if (((packet[0].toInt() and 0xF0) shr 4) != 4) return null

        val ihl = (packet[0].toInt() and 0x0F) * 4
        if (ihl < 20 || length < ihl + 8) return null
        if ((packet[9].toInt() and 0xFF) != 17) return null

        val udpOffset = ihl
        if (u16(packet, udpOffset + 2) != 53) return null

        val udpLength = u16(packet, udpOffset + 4)
        if (udpLength < 20) return null

        val dnsOffset = udpOffset + 8
        val dnsLength = minOf(udpLength - 8, length - dnsOffset)
        if (dnsLength < 12) return null

        val parsed = parseQuestion(packet, dnsOffset, dnsLength) ?: return null
        val host = parsed.first
        val questionEnd = parsed.second

        if (safeSearchEnabled) {
            val safeTarget = SafeSearch.target(host)
            if (safeTarget != null) {
                onSafeSearch(host)
                return wrapIpv4Udp(packet, ihl, buildCname(packet, dnsOffset, questionEnd, safeTarget))
            }
        }

        val dnsReply = if (matcherProvider().isBlocked(host)) {
            onBlocked(host)
            buildResponse(packet, dnsOffset, questionEnd, RCODE_NXDOMAIN)
        } else {
            forward(packet, dnsOffset, dnsLength)
                ?: buildResponse(packet, dnsOffset, questionEnd, RCODE_SERVFAIL)
        }

        return wrapIpv4Udp(packet, ihl, dnsReply)
    }

    // ---- DNS -----------------------------------------------------------------

    /** Returns the query name and the absolute offset just past QTYPE/QCLASS. */
    private fun parseQuestion(buf: ByteArray, offset: Int, length: Int): Pair<String, Int>? {
        val flags = u16(buf, offset + 2)
        if ((flags and 0x8000) != 0) return null // already a response
        if (u16(buf, offset + 4) < 1) return null // QDCOUNT

        val sb = StringBuilder()
        var p = offset + 12
        val limit = offset + length
        while (p < limit) {
            val labelLength = buf[p].toInt() and 0xFF
            if (labelLength == 0) {
                p++
                break
            }
            if ((labelLength and 0xC0) != 0) return null // compression pointer in a query
            if (p + 1 + labelLength > limit) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(buf, p + 1, labelLength, Charsets.US_ASCII))
            p += 1 + labelLength
            if (sb.length > 253) return null
        }
        if (p + 4 > limit) return null
        return sb.toString() to (p + 4) // skip QTYPE + QCLASS
    }

    private fun buildResponse(query: ByteArray, dnsOffset: Int, end: Int, rcode: Int): ByteArray {
        val out = query.copyOfRange(dnsOffset, end)
        out[2] = (out[2].toInt() or 0x80).toByte() // QR = 1
        out[3] = ((out[3].toInt() and 0x70) or 0x80 or rcode).toByte() // RA + RCODE
        for (i in 6..11) out[i] = 0 // AN, NS, AR counts
        return out
    }

    /**
     * Answers with a CNAME rather than rewriting the query. The client resolves the
     * target itself on the next lookup, which keeps DNS compression pointers intact.
     */
    private fun buildCname(query: ByteArray, dnsOffset: Int, end: Int, target: String): ByteArray {
        val question = query.copyOfRange(dnsOffset, end)
        val rdata = encodeName(target)
        val out = ByteArray(question.size + 12 + rdata.size)

        System.arraycopy(question, 0, out, 0, question.size)
        out[2] = (out[2].toInt() or 0x80).toByte() // QR = 1
        out[3] = ((out[3].toInt() and 0x70) or 0x80).toByte() // RA = 1, RCODE = 0
        out[6] = 0; out[7] = 1 // ANCOUNT = 1
        out[8] = 0; out[9] = 0 // NSCOUNT
        out[10] = 0; out[11] = 0 // ARCOUNT

        var p = question.size
        out[p++] = 0xC0.toByte(); out[p++] = 0x0C // NAME: pointer to offset 12
        out[p++] = 0; out[p++] = 5 // TYPE: CNAME
        out[p++] = 0; out[p++] = 1 // CLASS: IN
        out[p++] = 0; out[p++] = 0; out[p++] = 0; out[p++] = 60 // TTL 60s
        out[p++] = ((rdata.size shr 8) and 0xFF).toByte()
        out[p++] = (rdata.size and 0xFF).toByte()
        System.arraycopy(rdata, 0, out, p, rdata.size)
        return out
    }

    private fun encodeName(host: String): ByteArray {
        val labels = host.split('.').filter { it.isNotEmpty() }
        var size = 1
        for (label in labels) size += 1 + label.length
        val out = ByteArray(size)
        var p = 0
        for (label in labels) {
            out[p++] = label.length.toByte()
            for (c in label) out[p++] = c.code.toByte()
        }
        out[p] = 0
        return out
    }

    private fun forward(query: ByteArray, dnsOffset: Int, dnsLength: Int): ByteArray? {
        return try {
            DatagramSocket().use { socket ->
                if (!protect(socket)) return null
                socket.soTimeout = UPSTREAM_TIMEOUT_MS
                val payload = query.copyOfRange(dnsOffset, dnsOffset + dnsLength)
                socket.send(DatagramPacket(payload, payload.size, upstream, 53))
                val buffer = ByteArray(2048)
                val reply = DatagramPacket(buffer, buffer.size)
                socket.receive(reply)
                buffer.copyOfRange(reply.offset, reply.offset + reply.length)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---- packet plumbing -----------------------------------------------------

    private fun wrapIpv4Udp(original: ByteArray, ihl: Int, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val out = ByteArray(total)
        out[0] = 0x45
        out[2] = (total shr 8).toByte()
        out[3] = total.toByte()
        out[6] = 0x40 // DF
        out[8] = 64 // TTL
        out[9] = 17 // UDP
        System.arraycopy(original, 16, out, 12, 4) // src = original dst
        System.arraycopy(original, 12, out, 16, 4) // dst = original src
        val checksum = ipChecksum(out)
        out[10] = (checksum shr 8).toByte()
        out[11] = checksum.toByte()

        System.arraycopy(original, ihl + 2, out, 20, 2) // src port = original dst port
        System.arraycopy(original, ihl, out, 22, 2) // dst port = original src port
        val udpLength = 8 + payload.size
        out[24] = (udpLength shr 8).toByte()
        out[25] = udpLength.toByte()
        // out[26], out[27] stay zero: UDP checksum is optional over IPv4
        System.arraycopy(payload, 0, out, 28, payload.size)
        return out
    }

    private fun ipChecksum(header: ByteArray): Int {
        var sum = 0
        var i = 0
        while (i < 20) {
            sum += ((header[i].toInt() and 0xFF) shl 8) or (header[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    private fun u16(buf: ByteArray, at: Int): Int =
        ((buf[at].toInt() and 0xFF) shl 8) or (buf[at + 1].toInt() and 0xFF)

    companion object {
        private const val UPSTREAM = "1.1.1.1"
        private const val UPSTREAM_TIMEOUT_MS = 2000
        private const val RCODE_SERVFAIL = 2
        private const val RCODE_NXDOMAIN = 3
    }
}
