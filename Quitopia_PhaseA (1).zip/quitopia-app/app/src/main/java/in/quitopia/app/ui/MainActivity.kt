package in.quitopia.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.AndroidEntryPoint
import in.quitopia.app.ui.theme.QuitopiaTheme

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuitopiaTheme {
                val viewModel: AppViewModel = hiltViewModel()
                Root(viewModel)
            }
        }
    }
}

@Composable
private fun Root(viewModel: AppViewModel) {
    val state by viewModel.state.collectAsState()
    if (!state.commitment.onboardingDone) {
        OnboardingScreen(
            viewModel = viewModel,
            onFinished = { viewModel.completeOnboarding() }
        )
        return
    }

    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "dashboard") {
        composable("dashboard") {
            DashboardScreen(
                viewModel = viewModel,
                onOpenRecovery = { navController.navigate("recovery") },
                onOpenPlan = { navController.navigate("plan") },
                onOpenLists = { navController.navigate("lists") },
                onOpenContent = { navController.navigate("content") }
            )
        }
        composable("recovery") {
            RecoveryScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable("plan") {
            PlanScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable("lists") {
            ListEditorScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
        composable("content") {
            ContentScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }
    }
}
