package in.quitopia.app.domain

import in.quitopia.app.data.db.ScheduleEntity

/**
 * Evaluates time windows. Windows are compared as (day bit, minute of day) pairs and
 * never as scheduled alarms — exact alarms are restricted on modern Android and OEM
 * skins kill them anyway.
 */
object ScheduleEngine {

    /** @param dayIndex 0 = Monday ... 6 = Sunday, matching [ScheduleEntity.daysMask]. */
    fun isActive(schedule: ScheduleEntity, dayIndex: Int, minuteOfDay: Int): Boolean {
        if (!schedule.enabled) return false
        val start = schedule.startMinute
        val end = schedule.endMinute
        if (start == end) return false

        val todayBit = 1 shl dayIndex
        val yesterdayBit = 1 shl ((dayIndex + 6) % 7)

        return if (start < end) {
            (schedule.daysMask and todayBit) != 0 && minuteOfDay >= start && minuteOfDay < end
        } else {
            // Window crosses midnight: 22:00 -> 06:00
            val inEvening = (schedule.daysMask and todayBit) != 0 && minuteOfDay >= start
            val inMorning = (schedule.daysMask and yesterdayBit) != 0 && minuteOfDay < end
            inEvening || inMorning
        }
    }

    fun anyActive(schedules: List<ScheduleEntity>, dayIndex: Int, minuteOfDay: Int): Boolean =
        schedules.any { isActive(it, dayIndex, minuteOfDay) }

    /** Preset used by onboarding: every night, 22:00 to 06:00. */
    fun lateNightPreset(): ScheduleEntity = ScheduleEntity(
        daysMask = 0b1111111,
        startMinute = 22 * 60,
        endMinute = 6 * 60,
        tier = "HARD"
    )
}
