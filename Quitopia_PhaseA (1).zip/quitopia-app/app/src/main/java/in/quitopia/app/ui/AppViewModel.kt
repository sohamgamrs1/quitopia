package in.quitopia.app.ui

import android.content.Context
import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import in.quitopia.app.admin.QuitopiaDeviceAdmin
import in.quitopia.app.blocker.AppBlockerService
import in.quitopia.app.blocklist.Category
import in.quitopia.app.data.db.CustomRuleEntity
import in.quitopia.app.data.db.QuitopiaDatabase
import in.quitopia.app.data.db.RecoveryPlanEntity
import in.quitopia.app.data.db.StreakEntity
import in.quitopia.app.data.db.UrgeLogEntity
import in.quitopia.app.data.prefs.CommitmentState
import in.quitopia.app.data.prefs.CommitmentStore
import in.quitopia.app.data.prefs.CommitmentTier
import in.quitopia.app.data.prefs.PanicState
import in.quitopia.app.domain.CommitmentEngine
import in.quitopia.app.domain.PanicEngine
import in.quitopia.app.domain.RecoveryPlan
import in.quitopia.app.domain.StreakCalculator
import in.quitopia.app.util.Permissions
import in.quitopia.app.vpn.QuitopiaVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import javax.inject.Inject

data class IntegrityState(
    val vpnRunning: Boolean = false,
    val usageAccess: Boolean = false,
    val batteryExempt: Boolean = false,
    val privateDnsOk: Boolean = true,
    val deviceAdmin: Boolean = false,
    val blockedTotal: Int = 0,
    val safeSearchRewrites: Int = 0,
    val streakDays: Int = 0,
    val urgesLogged: Int = 0,
    val commitment: CommitmentState = CommitmentState(),
    val panic: PanicState = PanicState(),
    val panicActive: Boolean = false,
    val panicLabel: String = "",
    val categories: Set<Category> = setOf(Category.ADULT)
)

data class Article(
    val id: String,
    val title: String,
    val minutes: Int,
    val body: String
)

@HiltViewModel
class AppViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val commitmentStore: CommitmentStore,
    private val database: QuitopiaDatabase
) : ViewModel() {

    private val _state = MutableStateFlow(IntegrityState())
    val state: StateFlow<IntegrityState> = _state.asStateFlow()

    private val _urges = MutableStateFlow<List<UrgeLogEntity>>(emptyList())
    val urges: StateFlow<List<UrgeLogEntity>> = _urges.asStateFlow()

    private val _rules = MutableStateFlow<List<CustomRuleEntity>>(emptyList())
    val rules: StateFlow<List<CustomRuleEntity>> = _rules.asStateFlow()

    private val _plan = MutableStateFlow<RecoveryPlanEntity?>(null)
    val plan: StateFlow<RecoveryPlanEntity?> = _plan.asStateFlow()

    private val _articles = MutableStateFlow<List<Article>>(emptyList())
    val articles: StateFlow<List<Article>> = _articles.asStateFlow()

    init {
        viewModelScope.launch {
            commitmentStore.state.collect { commitment ->
                _state.value = _state.value.copy(commitment = commitment)
            }
        }
        viewModelScope.launch {
            commitmentStore.enabledCategories.collect { cats ->
                _state.value = _state.value.copy(categories = cats)
            }
        }
        viewModelScope.launch {
            commitmentStore.panic.collect { panic ->
                val remaining = PanicEngine.remainingMillis(panic, SystemClock.elapsedRealtime())
                _state.value = _state.value.copy(
                    panic = panic,
                    panicActive = remaining > 0,
                    panicLabel = PanicEngine.formatRemaining(remaining)
                )
            }
        }
        viewModelScope.launch {
            database.urgeLogDao().observeAll().collect {
                _urges.value = it
                _state.value = _state.value.copy(urgesLogged = it.size)
            }
        }
        viewModelScope.launch {
            database.blockEventDao().totalBlocked().collect {
                _state.value = _state.value.copy(blockedTotal = it)
            }
        }
        viewModelScope.launch {
            database.customRuleDao().observeAll().collect { _rules.value = it }
        }
        viewModelScope.launch {
            database.recoveryPlanDao().observe().collect { _plan.value = it }
        }
        loadArticles()
        refresh()
    }

    /** Call from every screen resume: permission state changes outside the app. */
    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            val streak = database.streakDao().get()
            val days = streak?.let {
                StreakCalculator.currentDays(it.currentStart, System.currentTimeMillis())
            } ?: 0
            _state.value = _state.value.copy(
                vpnRunning = QuitopiaVpnService.running.get(),
                usageAccess = Permissions.hasUsageAccess(context),
                batteryExempt = Permissions.isIgnoringBatteryOptimizations(context),
                privateDnsOk = Permissions.privateDnsMode(context) != "hostname",
                deviceAdmin = QuitopiaDeviceAdmin.isActive(context),
                streakDays = days
            )
        }
    }

    // ---- commitment ----------------------------------------------------------

    fun setTier(tier: CommitmentTier) {
        viewModelScope.launch {
            commitmentStore.setTier(tier)
            if (tier != CommitmentTier.OFF) AppBlockerService.start(context)
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            commitmentStore.completeOnboarding()
            database.streakDao().upsert(
                StreakEntity(
                    currentStart = System.currentTimeMillis(),
                    bestDays = 0,
                    lastBypassAt = null,
                    totalCleanDays = 0
                )
            )
        }
    }

    // ---- categories ----------------------------------------------------------

    fun toggleCategory(category: Category) {
        if (category == Category.ADULT) return // adult content is always on
        viewModelScope.launch {
            val current = _state.value.categories.toMutableSet()
            if (!current.add(category)) current.remove(category)
            commitmentStore.setCategories(current)
        }
    }

    // ---- panic ---------------------------------------------------------------

    fun startPanic(durationMs: Long = PanicEngine.DEFAULT_MS) {
        viewModelScope.launch {
            commitmentStore.startPanic(SystemClock.elapsedRealtime(), durationMs)
        }
    }

    fun stopPanic() {
        viewModelScope.launch { commitmentStore.stopPanic() }
    }

    // ---- custom rules --------------------------------------------------------

    fun addRule(pattern: String, isAllow: Boolean) {
        val trimmed = pattern.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            database.customRuleDao().insert(CustomRuleEntity(pattern = trimmed, isAllow = isAllow))
        }
    }

    fun deleteRule(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { database.customRuleDao().delete(id) }
    }

    // ---- recovery plan -------------------------------------------------------

    fun savePlan(answers: RecoveryPlan.Answers) {
        viewModelScope.launch(Dispatchers.IO) {
            val plan = RecoveryPlan.build(answers)
            database.recoveryPlanDao().save(RecoveryPlan.toEntity(answers, plan))
            database.scheduleDao().upsert(plan.schedule)
        }
    }

    fun planPreview(answers: RecoveryPlan.Answers): RecoveryPlan.Plan = RecoveryPlan.build(answers)

    // ---- content -------------------------------------------------------------

    private fun loadArticles() {
        viewModelScope.launch(Dispatchers.IO) {
            val items = runCatching {
                val raw = context.assets.open("content.json").bufferedReader().use { it.readText() }
                val array = JSONArray(raw)
                (0 until array.length()).map { i ->
                    val obj = array.getJSONObject(i)
                    Article(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        minutes = obj.optInt("minutes", 2),
                        body = obj.getString("body")
                    )
                }
            }.getOrDefault(emptyList())
            _articles.value = items
        }
    }

    // ---- protection ----------------------------------------------------------

    fun logUrge(trigger: String, outcome: String) {
        viewModelScope.launch(Dispatchers.IO) {
            database.urgeLogDao().insert(
                UrgeLogEntity(
                    timestamp = System.currentTimeMillis(),
                    trigger = trigger,
                    outcome = outcome
                )
            )
        }
    }

    fun startProtection() {
        QuitopiaVpnService.start(context)
        AppBlockerService.start(context)
        refresh()
    }

    fun stopProtection() {
        QuitopiaVpnService.stop(context)
        AppBlockerService.stop(context)
        refresh()
    }

    fun requestDisable() {
        viewModelScope.launch {
            commitmentStore.requestDisable(
                nowWall = System.currentTimeMillis(),
                nowElapsed = SystemClock.elapsedRealtime()
            )
        }
    }

    fun cooldownLabel(): String {
        val current = _state.value.commitment
        if (!current.hasPendingRequest) return "no pending request"
        val remaining = CommitmentEngine.remainingMillis(
            current,
            System.currentTimeMillis(),
            SystemClock.elapsedRealtime()
        )
        return CommitmentEngine.formatRemaining(remaining)
    }

    fun vpnConsentIntent() = Permissions.vpnConsentIntent(context)
    fun openUsageAccess() = Permissions.openUsageAccessSettings(context)
    fun openVpnSettings() = Permissions.openVpnSettings(context)
    fun openPrivateDns() = Permissions.openPrivateDnsSettings(context)
    fun requestBattery() = Permissions.requestBatteryExemption(context)
}
