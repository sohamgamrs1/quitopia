package in.quitopia.app.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import in.quitopia.app.blocklist.Category
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

enum class CommitmentTier { OFF, GENTLE, COMMITTED, HARD }

/**
 * Panic is short-lived and driven by elapsed realtime rather than the wall clock, so a
 * user cannot skip it by changing the system time. A reboot clears it — acceptable,
 * because the window is measured in minutes, not hours.
 */
data class PanicState(
    val startedElapsed: Long = 0L,
    val durationMs: Long = 0L
)

data class CommitmentState(
    val tier: CommitmentTier = CommitmentTier.OFF,
    val requestedWall: Long = 0L,
    val requestedElapsed: Long = 0L,
    val onboardingDone: Boolean = false
) {
    val hasPendingRequest: Boolean get() = requestedWall > 0L
}

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "quitopia")

@Singleton
class CommitmentStore @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private object Keys {
        val TIER = stringPreferencesKey("tier")
        val REQUESTED_WALL = longPreferencesKey("requested_wall")
        val REQUESTED_ELAPSED = longPreferencesKey("requested_elapsed")
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val BLOCKED_PACKAGES = stringSetPreferencesKey("blocked_packages")
        val CATEGORIES = stringSetPreferencesKey("categories")
        val PANIC_STARTED_ELAPSED = longPreferencesKey("panic_started_elapsed")
        val PANIC_DURATION_MS = longPreferencesKey("panic_duration_ms")
    }

    val state: Flow<CommitmentState> = context.dataStore.data.map { prefs ->
        CommitmentState(
            tier = runCatching {
                CommitmentTier.valueOf(prefs[Keys.TIER] ?: CommitmentTier.OFF.name)
            }.getOrDefault(CommitmentTier.OFF),
            requestedWall = prefs[Keys.REQUESTED_WALL] ?: 0L,
            requestedElapsed = prefs[Keys.REQUESTED_ELAPSED] ?: 0L,
            onboardingDone = prefs[Keys.ONBOARDED] ?: false
        )
    }

    val blockedPackages: Flow<Set<String>> =
        context.dataStore.data.map { it[Keys.BLOCKED_PACKAGES] ?: emptySet() }

    /** Which addictions this user is quitting. Adult is always on. */
    val enabledCategories: Flow<Set<Category>> = context.dataStore.data.map { prefs ->
        val keys = prefs[Keys.CATEGORIES] ?: setOf(Category.ADULT.key)
        keys.mapNotNull { Category.fromKey(it) }.ifEmpty { listOf(Category.ADULT) }.toSet()
    }

    val panic: Flow<PanicState> = context.dataStore.data.map { prefs ->
        PanicState(
            startedElapsed = prefs[Keys.PANIC_STARTED_ELAPSED] ?: 0L,
            durationMs = prefs[Keys.PANIC_DURATION_MS] ?: 0L
        )
    }

    suspend fun setTier(tier: CommitmentTier) {
        context.dataStore.edit { it[Keys.TIER] = tier.name }
    }

    suspend fun completeOnboarding() {
        context.dataStore.edit { it[Keys.ONBOARDED] = true }
    }

    suspend fun requestDisable(nowWall: Long, nowElapsed: Long) {
        context.dataStore.edit {
            it[Keys.REQUESTED_WALL] = nowWall
            it[Keys.REQUESTED_ELAPSED] = nowElapsed
        }
    }

    suspend fun clearDisableRequest() {
        context.dataStore.edit {
            it.remove(Keys.REQUESTED_WALL)
            it.remove(Keys.REQUESTED_ELAPSED)
        }
    }

    suspend fun setBlockedPackages(packages: Set<String>) {
        context.dataStore.edit { it[Keys.BLOCKED_PACKAGES] = packages }
    }

    suspend fun setCategories(categories: Set<Category>) {
        val safe = (categories + Category.ADULT).map { it.key }.toSet()
        context.dataStore.edit { it[Keys.CATEGORIES] = safe }
    }

    suspend fun startPanic(nowElapsed: Long, durationMs: Long) {
        context.dataStore.edit {
            it[Keys.PANIC_STARTED_ELAPSED] = nowElapsed
            it[Keys.PANIC_DURATION_MS] = durationMs
        }
    }

    suspend fun stopPanic() {
        context.dataStore.edit {
            it.remove(Keys.PANIC_STARTED_ELAPSED)
            it.remove(Keys.PANIC_DURATION_MS)
        }
    }
}
