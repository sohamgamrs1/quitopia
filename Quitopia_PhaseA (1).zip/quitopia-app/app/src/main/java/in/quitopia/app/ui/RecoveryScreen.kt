package in.quitopia.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecoveryScreen(viewModel: AppViewModel, onBack: () -> Unit) {
    val urges by viewModel.urges.collectAsState()
    val state by viewModel.state.collectAsState()

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    "Urges",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                OutlinedButton(onClick = onBack) { Text("Back") }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "${state.streakDays} clean days. ${urges.size} urges logged.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(20.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Right now, what is it?", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(
                            onClick = { viewModel.logUrge("STRESSED", "RESISTED") },
                            label = { Text("Stressed") }
                        )
                        AssistChip(
                            onClick = { viewModel.logUrge("BORED", "RESISTED") },
                            label = { Text("Bored") }
                        )
                        AssistChip(
                            onClick = { viewModel.logUrge("LONELY", "RESISTED") },
                            label = { Text("Lonely") }
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Logging it is the whole exercise. Nothing is shared, nothing leaves the phone.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Recent", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))

            if (urges.isEmpty()) {
                Text(
                    "Nothing logged yet. The first entry is the hardest.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                val format = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(urges.take(50)) { log ->
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                format.format(Date(log.timestamp)),
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(log.trigger, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
