package in.quitopia.app.vpn

/**
 * Safe search enforcement at the name-resolution layer.
 *
 * For a handful of search hosts we answer with a CNAME pointing at the engine's own
 * forced-safe variant. The client then resolves that name, which we pass through
 * normally. This avoids rewriting answers (and breaking DNS compression pointers),
 * and it works in every browser and every app that uses the system resolver.
 *
 * Limits, stated plainly: an app with its own resolver, or a typed IP address,
 * bypasses this. The integrity screen says so rather than pretending otherwise.
 */
object SafeSearch {

    private val rules: Map<String, String> = mapOf(
        "www.google.com" to "forcesafesearch.google.com",
        "google.com" to "forcesafesearch.google.com",
        "www.google.co.in" to "forcesafesearch.google.com",
        "google.co.in" to "forcesafesearch.google.com",
        "www.google.co.uk" to "forcesafesearch.google.com",
        "www.youtube.com" to "restrict.youtube.com",
        "youtube.com" to "restrict.youtube.com",
        "m.youtube.com" to "restrict.youtube.com",
        "youtube-nocookie.com" to "restrict.youtube.com",
        "www.bing.com" to "strict.bing.com",
        "bing.com" to "strict.bing.com",
        "duckduckgo.com" to "safe.duckduckgo.com",
        "www.duckduckgo.com" to "safe.duckduckgo.com",
        "search.yahoo.com" to "safesearch.search.yahoo.com"
    )

    /** Returns the forced-safe hostname for [host], or null if this host is not covered. */
    fun target(host: String): String? = rules[host.lowercase().trimEnd('.')]

    fun isCovered(host: String): Boolean = target(host) != null
}
