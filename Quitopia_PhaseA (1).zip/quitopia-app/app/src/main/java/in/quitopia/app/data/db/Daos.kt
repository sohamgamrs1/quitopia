package in.quitopia.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockEventDao {

    @Insert
    suspend fun insert(event: BlockEventEntity)

    @Query("SELECT COALESCE(SUM(count), 0) FROM block_event")
    fun totalBlocked(): Flow<Int>

    @Query("SELECT COALESCE(SUM(count), 0) FROM block_event WHERE hourBucket >= :since")
    fun blockedSince(since: Long): Flow<Int>

    @Query("DELETE FROM block_event WHERE hourBucket < :before")
    suspend fun purgeBefore(before: Long)
}

@Dao
interface UrgeLogDao {

    @Insert
    suspend fun insert(log: UrgeLogEntity)

    @Query("SELECT * FROM urge_log ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<UrgeLogEntity>>

    @Query("SELECT COUNT(*) FROM urge_log WHERE outcome = 'RESISTED'")
    fun resistedCount(): Flow<Int>
}

@Dao
interface JournalDao {

    @Insert
    suspend fun insert(entry: JournalEntryEntity)

    @Query("SELECT * FROM journal_entry ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<JournalEntryEntity>>

    @Query("DELETE FROM journal_entry")
    suspend fun deleteAll()
}

@Dao
interface StreakDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(streak: StreakEntity)

    @Query("SELECT * FROM streak WHERE id = 1")
    fun observe(): Flow<StreakEntity?>

    @Query("SELECT * FROM streak WHERE id = 1")
    suspend fun get(): StreakEntity?
}

@Dao
interface CustomRuleDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(rule: CustomRuleEntity): Long

    @Query("SELECT * FROM custom_rule ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<CustomRuleEntity>>

    @Query("DELETE FROM custom_rule WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface RecoveryPlanDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(plan: RecoveryPlanEntity)

    @Query("SELECT * FROM recovery_plan WHERE id = 1")
    fun observe(): Flow<RecoveryPlanEntity?>

    @Query("SELECT * FROM recovery_plan WHERE id = 1")
    suspend fun get(): RecoveryPlanEntity?
}

@Dao
interface ScheduleDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(schedule: ScheduleEntity): Long

    @Query("SELECT * FROM schedule WHERE enabled = 1")
    fun observeEnabled(): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM schedule")
    suspend fun all(): List<ScheduleEntity>

    @Query("DELETE FROM schedule WHERE id = :id")
    suspend fun delete(id: Long)
}
