package in.quitopia.app.blocklist

/**
 * What the user is quitting. The engine is identical for every category — only the
 * list, the copy and the pricing change, which is why this is data and not code.
 */
enum class Category(
    val key: String,
    val label: String,
    val blurb: String,
    val asset: String,
    val premium: Boolean
) {
    ADULT(
        key = "adult",
        label = "Adult content",
        blurb = "Pornography and explicit sites",
        asset = "blocklists/adult.txt",
        premium = false
    ),
    GAMBLING(
        key = "gambling",
        label = "Gambling",
        blurb = "Betting, casinos and cash rummy",
        asset = "blocklists/gambling.txt",
        premium = true
    ),
    SOCIAL(
        key = "social",
        label = "Short video & social",
        blurb = "Reels, Shorts and the scroll",
        asset = "blocklists/social.txt",
        premium = true
    ),
    GAMING(
        key = "gaming",
        label = "Gaming",
        blurb = "Game stores, launchers and titles",
        asset = "blocklists/gaming.txt",
        premium = true
    ),
    DATING(
        key = "dating",
        label = "Dating apps",
        blurb = "Dating and hookup platforms",
        asset = "blocklists/dating.txt",
        premium = true
    );

    companion object {
        fun fromKey(key: String): Category? = Category.entries.firstOrNull { it.key == key }
        fun defaults(): Set<Category> = setOf(ADULT)
    }
}
