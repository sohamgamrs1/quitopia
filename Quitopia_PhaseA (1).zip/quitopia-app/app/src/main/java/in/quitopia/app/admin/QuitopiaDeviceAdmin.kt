package in.quitopia.app.admin

import android.app.admin.DeviceAdminReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Uninstall friction, nothing else.
 *
 * This receiver requests no password policy, no remote wipe and no lock control. Its
 * only job is to force a deliberate act before Quitopia can be removed, and to give
 * the app a moment to record the attempt.
 */
class QuitopiaDeviceAdmin : DeviceAdminReceiver() {

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        Log.i(TAG, "admin disable requested")
        return "Turning this off removes the delay before Quitopia can be uninstalled. " +
            "If you are doing this late at night, wait until tomorrow."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Log.i(TAG, "admin disabled")
    }

    override fun onEnabled(context: Context, intent: Intent) {
        Log.i(TAG, "admin enabled")
    }

    companion object {
        private const val TAG = "QuitopiaAdmin"

        fun component(context: Context): ComponentName =
            ComponentName(context, QuitopiaDeviceAdmin::class.java)

        fun isActive(context: Context): Boolean {
            val manager = context.getSystemService(Context.DEVICE_POLICY_SERVICE)
                as android.app.admin.DevicePolicyManager
            return manager.isAdminActive(component(context))
        }
    }
}
