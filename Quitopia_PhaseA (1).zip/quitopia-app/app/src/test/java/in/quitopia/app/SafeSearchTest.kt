package in.quitopia.app

import in.quitopia.app.vpn.SafeSearch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SafeSearchTest {

    @Test
    fun googleIsForced() {
        assertEquals("forcesafesearch.google.com", SafeSearch.target("www.google.com"))
        assertEquals("forcesafesearch.google.com", SafeSearch.target("google.co.in"))
    }

    @Test
    fun youtubeIsRestricted() {
        assertEquals("restrict.youtube.com", SafeSearch.target("m.youtube.com"))
        assertEquals("restrict.youtube.com", SafeSearch.target("www.youtube.com"))
    }

    @Test
    fun bingAndDuckDuckGo() {
        assertEquals("strict.bing.com", SafeSearch.target("www.bing.com"))
        assertEquals("safe.duckduckgo.com", SafeSearch.target("duckduckgo.com"))
    }

    @Test
    fun caseAndTrailingDotAreNormalised() {
        assertEquals("forcesafesearch.google.com", SafeSearch.target("WWW.Google.COM."))
    }

    @Test
    fun unrelatedHostsAreLeftAlone() {
        assertNull(SafeSearch.target("example.com"))
        assertNull(SafeSearch.target("mail.google.com"))
    }
}
