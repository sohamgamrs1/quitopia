package in.quitopia.app

import in.quitopia.app.data.db.ScheduleEntity
import in.quitopia.app.domain.ScheduleEngine
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScheduleEngineTest {

    private val nightly = ScheduleEntity(
        daysMask = 0b1111111,
        startMinute = 22 * 60,
        endMinute = 6 * 60,
        tier = "HARD"
    )

    private val morning = ScheduleEntity(
        daysMask = 0b0000001, // Monday only
        startMinute = 9 * 60,
        endMinute = 17 * 60,
        tier = "COMMITTED"
    )

    @Test
    fun overnightWindowActiveBeforeMidnight() {
        assertTrue(ScheduleEngine.isActive(nightly, dayIndex = 3, minuteOfDay = 23 * 60))
    }

    @Test
    fun overnightWindowActiveAfterMidnight() {
        assertTrue(ScheduleEngine.isActive(nightly, dayIndex = 4, minuteOfDay = 5 * 60))
    }

    @Test
    fun overnightWindowInactiveDuringDay() {
        assertFalse(ScheduleEngine.isActive(nightly, dayIndex = 4, minuteOfDay = 12 * 60))
    }

    @Test
    fun dayWindowRespectsDayMask() {
        assertTrue(ScheduleEngine.isActive(morning, dayIndex = 0, minuteOfDay = 10 * 60))
        assertFalse(ScheduleEngine.isActive(morning, dayIndex = 1, minuteOfDay = 10 * 60))
    }

    @Test
    fun disabledScheduleNeverActive() {
        assertFalse(ScheduleEngine.isActive(nightly.copy(enabled = false), 3, 23 * 60))
    }
}
