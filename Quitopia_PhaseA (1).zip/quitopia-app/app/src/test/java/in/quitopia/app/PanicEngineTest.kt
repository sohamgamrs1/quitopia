package in.quitopia.app

import in.quitopia.app.data.prefs.PanicState
import in.quitopia.app.domain.PanicEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PanicEngineTest {

    private val started = PanicState(startedElapsed = 1_000L, durationMs = PanicEngine.DEFAULT_MS)

    @Test
    fun activeImmediately() {
        assertTrue(PanicEngine.isActive(started, 1_000L))
    }

    @Test
    fun countsDown() {
        assertEquals(
            PanicEngine.DEFAULT_MS - 60_000L,
            PanicEngine.remainingMillis(started, 61_000L)
        )
    }

    @Test
    fun expires() {
        val after = 1_000L + PanicEngine.DEFAULT_MS + 1L
        assertFalse(PanicEngine.isActive(started, after))
        assertEquals(0L, PanicEngine.remainingMillis(started, after))
    }

    @Test
    fun rebootClearsIt() {
        // elapsedRealtime restarted, so the stored start is in the future
        assertFalse(PanicEngine.isActive(started, 10L))
    }

    @Test
    fun noStateMeansNoPanic() {
        assertFalse(PanicEngine.isActive(PanicState(), 5_000L))
    }

    @Test
    fun formatsRemaining() {
        assertEquals("off", PanicEngine.formatRemaining(0L))
        assertEquals("1m 30s", PanicEngine.formatRemaining(90_000L))
        assertEquals("45s", PanicEngine.formatRemaining(45_000L))
    }
}
