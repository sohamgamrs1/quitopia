package in.quitopia.app

import in.quitopia.app.blocklist.DomainMatcher
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainMatcherTest {

    private val matcher = DomainMatcher.fromLines(
        listOf(
            "# comment",
            "example.com",
            "porn.example.net",
            "!safe.example.com"
        ).asSequence()
    )

    @Test
    fun blocksExactDomain() {
        assertTrue(matcher.isBlocked("example.com"))
    }

    @Test
    fun blocksSubdomains() {
        assertTrue(matcher.isBlocked("a.b.example.com"))
        assertTrue(matcher.isBlocked("porn.example.net"))
    }

    @Test
    fun allowlistAlwaysWins() {
        assertFalse(matcher.isBlocked("safe.example.com"))
        assertTrue(matcher.isBlocked("other.example.com"))
    }

    @Test
    fun unrelatedDomainsPass() {
        assertFalse(matcher.isBlocked("wikipedia.org"))
        assertFalse(matcher.isBlocked("notexample.com"))
    }

    @Test
    fun normalisesInput() {
        assertTrue(matcher.isBlocked("  HTTPS://Example.COM/some/path  "))
        assertTrue(matcher.isBlocked("example.com."))
    }

    @Test
    fun rejectsGarbage() {
        assertFalse(matcher.isBlocked(""))
        assertFalse(matcher.isBlocked("localhost"))
    }
}
