package in.quitopia.app

import in.quitopia.app.data.prefs.CommitmentState
import in.quitopia.app.data.prefs.CommitmentTier
import in.quitopia.app.domain.CommitmentEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CommitmentEngineTest {

    private val requested = CommitmentState(
        tier = CommitmentTier.COMMITTED,
        requestedWall = 1_000_000L,
        requestedElapsed = 5_000L
    )

    @Test
    fun cooldownNotElapsedImmediately() {
        val remaining = CommitmentEngine.remainingMillis(
            requested,
            nowWall = 1_000_000L + 60_000L,
            nowElapsed = 5_000L + 60_000L
        )
        assertEquals(CommitmentEngine.COOLDOWN_MS - 60_000L, remaining)
    }

    @Test
    fun clockForwardCheatDoesNothing() {
        // User jumps the wall clock a week ahead; elapsed realtime barely moved.
        val remaining = CommitmentEngine.remainingMillis(
            requested,
            nowWall = 1_000_000L + 7 * 24 * 3600_000L,
            nowElapsed = 5_000L + 1_000L
        )
        assertEquals(CommitmentEngine.COOLDOWN_MS - 1_000L, remaining)
    }

    @Test
    fun clockBackwardCheatDoesNothing() {
        val remaining = CommitmentEngine.remainingMillis(
            requested,
            nowWall = 1_000_000L - 7 * 24 * 3600_000L,
            nowElapsed = 5_000L + 1_000L
        )
        assertEquals(CommitmentEngine.COOLDOWN_MS - 1_000L, remaining)
    }

    @Test
    fun cooldownElapses() {
        val remaining = CommitmentEngine.remainingMillis(
            requested,
            nowWall = 1_000_000L + CommitmentEngine.COOLDOWN_MS,
            nowElapsed = 5_000L + CommitmentEngine.COOLDOWN_MS
        )
        assertEquals(0L, remaining)
        assertTrue(
            CommitmentEngine.canDisableNow(
                requested,
                nowWall = 1_000_000L + CommitmentEngine.COOLDOWN_MS,
                nowElapsed = 5_000L + CommitmentEngine.COOLDOWN_MS
            )
        )
    }

    @Test
    fun cannotDisableWithoutRequest() {
        assertFalse(CommitmentEngine.canDisableNow(requested, 2_000_000L, 10_000_000L))
    }
}
