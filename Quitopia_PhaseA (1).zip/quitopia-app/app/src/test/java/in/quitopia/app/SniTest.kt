package in.quitopia.app

import in.quitopia.app.vpn.Sni
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SniTest {

    /** Builds the smallest well-formed TLS ClientHello that carries a server_name. */
    private fun clientHello(host: String): ByteArray {
        val name = host.toByteArray(Charsets.US_ASCII)
        val sni = ByteArray(9 + name.size)
        var p = 0
        sni[p++] = 0x00; sni[p++] = 0x00 // extension type: server_name
        val extLen = 5 + name.size
        sni[p++] = ((extLen shr 8) and 0xFF).toByte(); sni[p++] = (extLen and 0xFF).toByte()
        val listLen = 3 + name.size
        sni[p++] = ((listLen shr 8) and 0xFF).toByte(); sni[p++] = (listLen and 0xFF).toByte()
        sni[p++] = 0x00 // host_name
        sni[p++] = ((name.size shr 8) and 0xFF).toByte(); sni[p++] = (name.size and 0xFF).toByte()
        System.arraycopy(name, 0, sni, p, name.size)

        val body = ArrayList<Byte>()
        body.add(0x03); body.add(0x03) // legacy version
        repeat(32) { body.add(0) } // random
        body.add(0) // session id length
        body.add(0x00); body.add(0x02) // cipher suites length
        body.add(0x13); body.add(0x01) // TLS_AES_128_GCM_SHA256
        body.add(0x01); body.add(0x00) // compression: null
        body.add(((sni.size shr 8) and 0xFF).toByte()); body.add((sni.size and 0xFF).toByte())
        sni.forEach { body.add(it) }

        val handshake = ArrayList<Byte>()
        handshake.add(0x01) // ClientHello
        val len = body.size
        handshake.add(((len shr 16) and 0xFF).toByte())
        handshake.add(((len shr 8) and 0xFF).toByte())
        handshake.add((len and 0xFF).toByte())
        handshake.addAll(body)

        val out = ArrayList<Byte>()
        out.add(0x16) // handshake record
        out.add(0x03); out.add(0x01)
        val recordLen = handshake.size
        out.add(((recordLen shr 8) and 0xFF).toByte()); out.add((recordLen and 0xFF).toByte())
        out.addAll(handshake)
        return out.toByteArray()
    }

    @Test
    fun extractsHostname() {
        val payload = clientHello("www.example.com")
        assertEquals("www.example.com", Sni.extract(payload))
    }

    @Test
    fun handlesLongerHostnames() {
        val payload = clientHello("a.b.c.very-long-subdomain.example.co.in")
        assertEquals("a.b.c.very-long-subdomain.example.co.in", Sni.extract(payload))
    }

    @Test
    fun ignoresPlainHttp() {
        val plain = "GET / HTTP/1.1\r\nHost: example.com\r\n\r\n".toByteArray()
        assertNull(Sni.extract(plain))
    }

    @Test
    fun ignoresTruncatedPayload() {
        val payload = clientHello("www.example.com")
        assertNull(Sni.extract(payload, 20))
    }
}
