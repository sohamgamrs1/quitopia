# Room
-keep class in.quitopia.app.data.db.** { *; }
# Hilt generated components
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
# Keep the VPN service entry point name stable for always-on VPN
-keep class in.quitopia.app.vpn.QuitopiaVpnService { *; }
